package ru.alihan.borderline;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Borderline Depth client mod starter.
 * The post-processing effect is not yet wired into Minecraft's render loop.
 */
public final class BorderlineMod implements ClientModInitializer {
    public static final String MOD_ID = "borderline";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Borderline Depth loaded. Outline effect is not active yet.");
    }
}
